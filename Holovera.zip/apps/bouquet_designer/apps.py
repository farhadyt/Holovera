from django.apps import AppConfig


class BouquetDesignerConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.bouquet_designer'
